<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Summary</title>
<!--===CSS files ===-->
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
	<link rel="stylesheet" href="css/font-awesome.min.css" />
	<link rel="stylesheet" href="css/linea-icon.css" />
	<link rel="stylesheet" href="css/fancy-buttons.css" />
    <link rel="stylesheet" href="style.css" />
    
    

</head>

<body>
<?php
$three_years = 36;
$four_years = 48;
$five_years = 60;
$six_years = 72;

if(isset($_POST['next3'])){
	$_SESSION['telecom_cost'] = $telecom_cost = $_POST['telecom'];
	$_SESSION['maintenance_cost'] = $maintenance_cost = $_POST['maintenance'];
	$_SESSION['additional_cost'] = $additional_cost = $_POST['addition'];
	$_SESSION['lease_cost'] = $lease_cost = $_POST['lease_cost'];
	$_SESSION['staffing_cost'] = $staffing_cost = $_POST['staffing'];
	$total_pbx = $_SESSION['total_pbx'] + $telecom_cost + $maintenance_cost + $additional_cost + $lease_cost + $staffing_cost;

	$_SESSION['total_pbx2'] = $total_pbx;
}
?>
<div class="row container-fluid box">
	<div id="main_container" class="col-md-12 nopadding">
		<div id="calc_content">
                <div class="col-md-12 nopadding summary_content">
                    <table>
                    <form method="post">
                    <div class="col-md-8 nopadding">
                    <button class="menu col-md-4 nopadding" formaction="welcome.php" name="bus_profile" disabled="disabled"><div style="float:left;"><h1>1</h1></div><div><br />Current Business Profile</div></button>
                    <button class="menu col-md-4 nopadding" formaction="usage.php" name="usage_fees" disabled="disabled"><div style="float:left;"><h1>2</h1></div><div><br />Your Usage Fee</div></button>
                    <button class="menu col-md-4 nopadding" formaction="system.php" name="your_system" disabled="disabled"><div style="float:left;"><h1>3</h1></div><div><br />Your System</div></button>
                    </div>
                    <button class="menu col-md-4 nopadding" name="your_system" disabled="disabled"><div><br />Phone Savings</div></button>				
                    </form>
                    </table>
                    
                    <div id="calc_body">
                    	<table class="col-md-12 nopadding">
                        	<tr>
                            	<th class="col-md-8 nopadding">User Phone-Sysytem Comparison</th>
                                <th class="col-md-2 nopadding">RingCentral Office</th>
                                <th class="col-md-2 nopadding">On-Premise PBX</th>
                            </tr>
                            <tr>
                            	<td>On-Premise hardware - PBX, server cards<sup>1</sup></td>
                                <td>$0</td>
                                <td>N/A</td>
                            </tr>
                             <tr>
                            	<td>PBX Software licences<sup>1</sup></td>
                                <td>$0</td>
                                <td>N/A</td>
                                
                            </tr>
                            <tr>
                            	<td>One-time phone cost<sup>2</sup></td>
                                <td>$0</td>
                                <td>N/A</td>
                            </tr>
                            <tr>
                            	<td>Setup and Implementation per location</td>
                                <td>FREE</td>
                                <td>N/A</td>
                            </tr>
                            <tr>
                            	<td>Phone configuration</td>
                                <td>FREE</td>
                                <td>N/A</td>    
                            </tr>
                            <tr>
                            	<td>Integration with Microsoft Office and Microsoft Outlook</td>
                                <td>FREE</td>
                                <td>N/A</td>
                                
                            </tr>
                            <tr>
                            	<td>Integration with BOX, Google Docs, Dropbox</td>
                                <td>FREE</td>
                                <td>N/A</td>
                            </tr>
                            <tr>
                            	<th>Monthly Cost</th>
                            </tr>
                            <tr>
                            	<td>All inclusive pricing</td>
                                <td><?php echo $_SESSION['total_icall']; ?></td>
                                <td>N/A</td>
                            </tr>
                            <tr>
                            	<td>Unlimited Local and long-distance calling</td>
                                <td>FREE</td>
                                <td><?php echo $_SESSION['long_dist_cost']; ?></td>
                            </tr>
                            <tr>
                            	<td>Toll-free number and minutes</td>
                                <td>FREE</td>
                                <td><?php echo $_SESSION['toll_free_cost']; ?></td>  
                            </tr>
                            <tr>
                            	<td>Local numbers for each user</td>
                                <td>FREE</td>
                                <td><?php echo $_SESSION['phone_no_cost'] ?></td>
                            </tr>
                            <tr>
                            	<td>Unlimited Internet fax/td>
                                <td>FREE</td>
                                <td><?php echo $_SESSION['fax_cost'] ?></td> 
                            </tr>
                            <tr>
                            	<td>Telecom Trunk Line</td>
                                <td>$0</td>
                                <td><?php echo $_SESSION['telecom_cost']; ?></td>
                            </tr>
                            <tr>
                            	<td>Ongoing system management and configuration</td>
                                <td>FREE</td>
                                <td><?php echo $_SESSION['maintenance_cost']; ?></td>
                            </tr>
                            <tr>
                            	<td>Additional one-time costs</td>
                                <td>FREE</td>
                                <td><?php echo $_SESSION['additional_cost']; ?></td>
                            </tr>
                            <tr>
                            	<td>Lease costs</td>
                                <td>$0</td>
                                <td><?php echo $_SESSION['lease_cost']; ?></td>
                            </tr>
                            <tr>
                            	<td>24/7 live support</td>
                                <td>FREE</td>
                                <td><?php echo $_SESSION['staffing_cost']; ?></td>   
                            </tr>
                            <tr>
                            	<td>Presence across multiple devices<sup>2</sup></td>
                                <td>FREE</td>
                                <td>N/A</td>   
                            </tr>
                            <tr>
                            	<td>"Touch" management on iphone, Android and Blackberry</td>
                                <td>FREE</td>
                                <td>N/A</td>   
                            </tr>
                            <tr>
                            	<th>Total Monthly cost</th>
                                <td><?php echo $_SESSION['total_icall']; ?></td>
                                <td><?php echo $_SESSION['total_pbx2']; ?></td>   
                            </tr>
                            <tr>
                            	<th>Total 3-Year Cost</th>
                                <td><?php echo $_SESSION['total_icall'] * $three_years; ?></td>
                                <td><?php echo $_SESSION['total_pbx2'] * $three_years; ?></td>   
                            </tr>
                            <tr>
                            	<th>Total 3-Year Savings</th>
                                <td>$0 Save 0%</td> 
                            </tr>
                            <tr>
                            	<th>Total 4-Year Cost</th>
                                <td><?php echo $_SESSION['total_icall'] * $four_years; ?></td>
                                <td><?php echo $_SESSION['total_pbx2'] * $four_years; ?></td>   
                            </tr>
                            <tr>
                            	<th>Total 4-Year Savings</th>
                                <td>$0 Save 0%</td> 
                            </tr>
                            <tr>
                            	<th>Total 5-Year Cost</th>
                                <td><?php echo $_SESSION['total_icall'] * $five_years; ?></td>
                                <td><?php echo $_SESSION['total_pbx2'] * $five_years; ?></td>   
                            </tr>
                            <tr>
                            	<th>Total 5-Year Savings</th>
                                <td>$0 Save 0%</td> 
                            </tr>
                            <tr>
                            	<th>Total 6-Year Cost</th>
                                <td><?php echo $_SESSION['total_icall'] * $six_years; ?></td>
                                <td><?php echo $_SESSION['total_pbx2'] * $six_years; ?></td>   
                            </tr>
                            <tr>
                            	<th>Total 6-Year Savings</th>
                                <td>$0 Save 0%</td> 
                            </tr>
                            
                        </table>
                   







                    	           
                    </div> 
              	</div>
                      
        </div>
    </div>
</div>   


<script src="custom.js" type="text/javascript"></script>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/angular.min.js" type="text/javascript"></script>
<?php // session_destroy(); ?>
</body>
</html>
