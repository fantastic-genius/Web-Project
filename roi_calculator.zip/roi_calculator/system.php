<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>System</title>
	<!--===CSS files ===-->
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
	<link rel="stylesheet" href="css/font-awesome.min.css" />
	<link rel="stylesheet" href="css/linea-icon.css" />
	<link rel="stylesheet" href="css/fancy-buttons.css" />
    <link rel="stylesheet" href="style.css" />
    

</head>

<body>
<?php



if(isset($_POST['next2'])){
	$_SESSION['long_dist_cost'] = $long_dist_cost = $_POST['long_distance'];
	$_SESSION['toll_free_cost'] = $toll_free_cost = $_POST['toll_free'];
	$_SESSION['phone_no_cost'] = $phone_no_cost = $_POST['phone_no'];
	$_SESSION['fax_cost'] = $fax_cost = $_POST['fax'];
	$total_pbx = $long_dist_cost + $toll_free_cost + $phone_no_cost + $fax_cost;

	$_SESSION['total_pbx'] = $total_pbx;
}

$total_pbx = 0;
$three_years = 36;
$four_years = 48;
$five_years = 60;
$six_years = 72;
if(isset($_POST['contract'])){
	$contract_status = $_POST['contract'];
	if($contract_status == 'yr3'){
		$total_icall =  $_SESSION['total_icall'] * $three_years;
		$total_pbx = $_SESSION['total_pbx'] * $three_years;
	}else if($contract_status == 'yr4'){
		$total_icall =  $_SESSION['total_icall'] * $four_years;
		$total_pbx =  $_SESSION['total_pbx'] * $four_years;
	}else if($contract_status == 'yr5'){
		$total_icall =  $_SESSION['total_icall'] * $five_years;
		$total_pbx =  $_SESSION['total_pbx'] * $five_years;
	}else if($contract_status == 'yr6'){
		$total_icall =  $_SESSION['total_icall'] * $six_years;
		$total_pbx =  $_SESSION['total_pbx'] * $six_years;
	}else{
		$total_icall = $_SESSION['total_icall'];
		$total_pbx =  $_SESSION['total_pbx'];
	}
	$_SESSION['new_total_icall'] = $total_icall;
	
							
	$_SESSION['new_total_pbx'] = $total_pbx;
	

}
?>
<div class="row">
	<div id="main_container" class="col-md-12 box">
		<div id="calc_content" style="display:block">
                <div class="col-md-8 content">
                    <table>
                    <form method="post">
                    <button class="menu col-md-4" formaction="welcome.php" name="bus_profile"><div style="float:left;"><h1>1</h1></div><div><br />Current Business Profile</div></button>
                    <button class="menu col-md-4" formaction="usage.php" name="usage_fees"><div style="float:left;"><h1>2</h1></div><div><br />Your Usage Fee</div></button>
                    <button class="menu col-md-4" formaction="system.php" name="your_system"><div style="float:left;"><h1>3</h1></div><div><br />Your System</div></button>				
                    </form>
                    </table>
                    
                    <div id="calc_body">
                    	<!-- For Systems -->
                        <form  id="system" name="system" method="post" >
                            <table style="display:inline-block">
                                <tr>
                                    <th style="text-align:left">Telecom Trunk Line</th>
                                    <td><input type="number" id="telecom" name="telecom" required="required"  /></td>
                                </tr>
                                <tr>
                                    <th style="text-align:left">Maintenance and support costs</th>
                                    <td><input type="number" id="maintenance" name="maintenance" required="required"  /></td>
                                </tr>
                                 <tr>
                                    <th style="text-align:left">Additional one-time costs</th>
                                    <td><input type="number" id="addition" name="addition" required="required"  /></td>
                                </tr>
                                <tr>
                                    <th style="text-align:left">Lease costs</th>
                                    <td><input type="number" id="lease_cost" name="lease_cost" required="required"  /></td>
                                </tr>
                                <tr>
                                    <th style="text-align:left">IT Staffing costs (Professional services)</th>
                                    <td><input type="number" id="staffing" name="staffing" required="required"  /></td>
                                </tr>
                            </table>
                            <div>
                            <input type="submit" id="next3" name="next3" value="Next" formaction="summary.php" style="margin-top:20px; margin-left: 20px; float:right"  />
                            <input type="submit" id="previous3" name="previous3" value="Previous" formaction="usage.php" style="margin-top:20px; float:right"/>
                            </div>
                        </form>                    
                    </div> 
              	</div>
                <div class="col-md-4 content">
                    <table>
                        <tr>
                            <h2>Phone Savings</h2>
                        </tr>
                        <tr>
                            <th></th>
                            <th>RingCentral Office</th>
                            <th>On-Premise PBX</th>
                        
                        </tr>
                        <tr>
                            <th>Total Monthly Cost</th>
                            <td>$<?php 
									if(isset($_POST['next2'])){
										echo $_SESSION['total_icall'] ;
									}else if(isset($_POST['contract'])){
										echo $_SESSION['new_total_icall'];
									}else if(isset($_POST['your_system'])){
										echo $_SESSION['total_icall'] ;
									}else{
										echo 0;
									}

							  ?></td>
                            <td>$<?php 
									if(isset($_POST['next2'])){
										echo $_SESSION['total_pbx'];
									}else if(isset($_POST['contract'])){
										echo $_SESSION['new_total_pbx'];
									}else if(isset($_POST['your_system'])){
										echo $_SESSION['total_pbx'];
									}else{
										echo 0;
									}
							
							
							?></td>
                        </tr>
                        <tr>
                            <th>Your 2-Years Savings</th>
                            <td>$0 Save 0%</td>
                            
                        </tr>
                    
                    </table>
                    <tr style="margin-top:200px">
                    	<form method="post" action="" onchange='this.submit()'>
                        <td><input type="radio" name="contract" value="non" <?php if(!isset($_POST['contract']) || (isset($_POST['contract']) && $_POST['contract'] == 'non' )){ echo'checked = "checked"' ; }?>/>  Monthly, no contract </td><br/>
                        <td><input type="radio" name="contract" value="yr3"  <?php if(isset($_POST['contract']) && $_POST['contract'] == 'yr3'){ echo'checked = "checked"' ; }?>/>  Monthly, 3 year contract</td><br/>
                        <td><input type="radio" name="contract" value="yr4" <?php if(isset($_POST['contract']) && $_POST['contract'] == 'yr4'){ echo'checked = "checked"' ; }?>/>  Monthly, 4 year contract</td><br/>
                        <td><input type="radio" name="contract" value="yr5" <?php if(isset($_POST['contract']) && $_POST['contract'] == 'yr5'){ echo'checked = "checked"' ; }?>/>  Monthly, 5 year contract</td><br/>
                        <td><input type="radio" name="contract" value="yr6" <?php if(isset($_POST['contract']) && $_POST['contract'] == 'yr6'){ echo'checked = "checked"' ; }?>/>  Monthly, 6 year contract</td><br/>
                        <noscript><input type="submit" name="next4" value="check" style="margin-top:20px; margin-left: 20px; float:right" /></noscript>
                     </form>
                     </tr>
                     
                    
            	</div>      
        </div>
    </div>
</div>  
    <!--===Javascript files ===-->
    <script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="custom.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/angular.min.js" type="text/javascript"></script> 
</body>
</html>