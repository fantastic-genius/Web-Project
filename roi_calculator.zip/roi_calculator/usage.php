<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Usage Fees</title>

	<!--===CSS files ===-->
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
	<link rel="stylesheet" href="css/font-awesome.min.css" />
	<link rel="stylesheet" href="css/linea-icon.css" />
	<link rel="stylesheet" href="css/fancy-buttons.css" />
    <link rel="stylesheet" href="style.css" />
    
    <!--===Javascript files ===-->
    <script src="custom.js" type="text/javascript"></script>
	<script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/angular.min.js" type="text/javascript"></script>
</head>

<body>
<div class="row">
<?php
$total_employee = $total_icall = 0;
$rate = '';


if(isset($_POST['next1'])){
	$_SESSION['location_no'] = $location_no = $_POST["location"];
	$_SESSION['employee_no'] = $employee_no = $_POST['employee'];
	$_SESSION['home_worker_no'] = $home_worker_no = $_POST['home_employee'];
	$total_employee = $employee_no + $home_worker_no;
	
	if($total_employee <= 19){
		$rate = 32.99;
	}else if($total_employee <= 49){
		$rate = 23.99;
	}else{
		$rate =19.99;
	}
	$total_icall = $total_employee * $rate;
	$_SESSION['total_icall'] = $total_icall;
	
	if(!isset($_SESSION['total_pbx'])){
		$_SESSION['total_pbx_use'] = 0;
	}else{
		$_SESSION['total_pbx_use'] =  $_SESSION['total_pbx'];
	}
	
	
	
}


if(isset($_POST['previous3'])){ 
	$_SESSION['total_icall_pro'] =  $_SESSION['total_icall']; 
	
	$_SESSION['total_pbx_use'] =  $_SESSION['total_pbx'];
}


$total_pbx = 0;
$three_years = 36;
$four_years = 48;
$five_years = 60;
$six_years = 72;
if(isset($_POST['contract'])){
	$contract_status = $_POST['contract'];
	if($contract_status == 'yr3'){
		$total_icall =  $_SESSION['total_icall'] * $three_years;
		$total_pbx = $_SESSION['total_pbx_use'] * $three_years;
	}else if($contract_status == 'yr4'){
		$total_icall =  $_SESSION['total_icall'] * $four_years;
		$total_pbx =  $_SESSION['total_pbx_use'] * $four_years;
	}else if($contract_status == 'yr5'){
		$total_icall =  $_SESSION['total_icall'] * $five_years;
		$total_pbx =  $_SESSION['total_pbx_use'] * $five_years;
	}else if($contract_status == 'yr6'){
		$total_icall =  $_SESSION['total_icall'] * $six_years;
		$total_pbx =  $_SESSION['total_pbx_use'] * $six_years;
	}else{
		$total_icall = $_SESSION['total_icall'];
		$total_pbx =  $_SESSION['total_pbx_use'];
	}
	$_SESSION['new_total_icall'] = $total_icall;
							
	$_SESSION['new_total_pbx'] = $total_pbx;

}

if(isset($_POST['usage_fees'])){
	$_SESSION['new_total_icall'] = $_SESSION['total_icall'];
	
	if(!isset($_SESSION['total_pbx'])){
		$_SESSION['total_pbx_use'] = 0;
	}else{
		$_SESSION['total_pbx_use'] =  $_SESSION['total_pbx'];
	}
		
}
?>

	<div id="main_container" class="col-md-12 box">
		<div id="calc_content" style="display:block">
                <div class="col-md-8 content">
                    <table>
                    <form method="post">
                    <button class="menu col-md-4" formaction="welcome.php" name="bus_profile"><div style="float:left;"><h1>1</h1></div><div><br />Current Business Profile</div></button>
                    <button class="menu col-md-4" formaction="usage.php" name="usage_fees"><div style="float:left;"><h1>2</h1></div><div><br />Your Usage Fee</div></button>
                    <button class="menu col-md-4" disabled="disabled" name="your_system"><div style="float:left;"><h1>3</h1></div><div><br />Your System</div></button>				
                    </form>
                    </table>
                    
                    <div id="calc_body">
                    	<!-- For Usage -->
                    	<form  id="fees" name="fees" method="post" action="">
                            <table style="display:inline-block">
                                <tr>
                                    <th style="text-align:left">Local and long-distance calling costs</th>
                                    <td><input type="number" name="long_distance" required="required" value="<?php if(isset($_POST['previous3']) || isset($_POST['contract']) || isset($_POST['next1']) || isset($_POST['usage_fees'])){ 
									if(!isset($_SESSION['long_dist_cost'])){
										echo '';
									}else{
										echo $_SESSION['long_dist_cost']; 
									}}?>" /></td>
                                </tr>
                                <tr>
                                    <th style="text-align:left">Toll-free costs</th>
                                    <td><input type="number" name="toll_free" required="required" value="<?php if(isset($_POST['previous3']) || isset($_POST['contract']) || isset($_POST['next1']) || isset($_POST['usage_fees'])){ 
									if(!isset($_SESSION['toll_free_cost'])){
										echo '';
									}else{
										echo $_SESSION['toll_free_cost']; 
									}}?>" /></td>
                                </tr>
                                 <tr>
                                    <th style="text-align:left">Phone numbers (DIDs) costs</th>
                                    <td><input type="number" name="phone_no" required="required" value="<?php if(isset($_POST['previous3']) || isset($_POST['contract']) || isset($_POST['next1']) || isset($_POST['usage_fees'])){ 
									if(!isset($_SESSION['phone_no_cost'])){
										echo '';
									}else{
										echo $_SESSION['phone_no_cost']; 
									}}?>" /></td>
                                </tr>
                                <tr>
                                    <th style="text-align:left">Fax costs</th>
                                    <td><input type="number" name="fax" required="required" value="<?php if(isset($_POST['previous3']) || isset($_POST['contract']) || isset($_POST['next1']) || isset($_POST['usage_fees'])){ 
									if(!isset($_SESSION['fax_cost'])){
										echo '';
									}else{
										echo $_SESSION['fax_cost']; 
									}}?>" /></td>
                                </tr>
                            </table>
                            <div>
                                <input type="submit" name="next2" value="Next" formaction="system.php" style="margin-top:20px; margin-left: 20px; float:right" />
                                <input type="submit" name="previous2" value="Previous" formaction="welcome.php" style="margin-top:20px; float:right"/>
                            </div>
                        </form>
                    </div>                
                </div>
                <div class="col-md-4 content">
                    <table>
                        <tr>
                            <h2>Phone Savings</h2>
                        </tr>
                        <tr>
                            <th></th>
                            <th>RingCentral Office</th>
                            <th>On-Premise PBX</th>
                        
                        </tr>
                        <tr>
                            <th>Total Monthly Cost</th>
                            <td>$<?php 
									if(isset($_POST['next1'])){
										echo $total_icall ;
									}else if(isset($_POST['previous3'])){
										echo $_SESSION['total_icall_pro'] ;
									}else if(isset($_POST['contract'])){
										echo $_SESSION['new_total_icall'];
									}else if(isset($_POST['usage_fees'])){
										echo $_SESSION['new_total_icall'];
									}else{
										echo 0;
									}

							  ?></td>
                            <td>$<?php 
									if(isset($_POST['next1'])){
										echo $_SESSION['total_pbx_use'];
									}else if(isset($_POST['previous3'])){
										echo $_SESSION['total_pbx_use'];
									}else if(isset($_POST['contract'])){
										echo $_SESSION['new_total_pbx'];
									}else if(isset($_POST['usage_fees'])){
										echo $_SESSION['total_pbx_use'];
									}else{
										echo 0;
									}
							
							
							?></td>
                        </tr>
                        <tr>
                            <th>Your 2-Years Savings</th>
                            <td>$0 Save 0%</td>
                            
                        </tr>
                    
                    </table>
                    <tr style="margin-top:200px">
                    	<form method="post" action="" onchange='this.submit()'>
                        <td><input type="radio" name="contract" value="non" <?php if(!isset($_POST['contract']) || (isset($_POST['contract']) && $_POST['contract'] == 'non' )){ echo'checked = "checked"' ; }?>/>  Monthly, no contract </td><br/>
                        <td><input type="radio" name="contract" value="yr3"  <?php if(isset($_POST['contract']) && $_POST['contract'] == 'yr3'){ echo'checked = "checked"' ; }?>/>  Monthly, 3 year contract</td><br/>
                        <td><input type="radio" name="contract" value="yr4" <?php if(isset($_POST['contract']) && $_POST['contract'] == 'yr4'){ echo'checked = "checked"' ; }?>/>  Monthly, 4 year contract</td><br/>
                        <td><input type="radio" name="contract" value="yr5" <?php if(isset($_POST['contract']) && $_POST['contract'] == 'yr5'){ echo'checked = "checked"' ; }?>/>  Monthly, 5 year contract</td><br/>
                        <td><input type="radio" name="contract" value="yr6" <?php if(isset($_POST['contract']) && $_POST['contract'] == 'yr6'){ echo'checked = "checked"' ; }?>/>  Monthly, 6 year contract</td><br/>
                        <noscript><input type="submit" name="next4" value="check" style="margin-top:20px; margin-left: 20px; float:right" /></noscript>
                     </form>
                     </tr>
                     
                    
             	</div>
		</div>
    </div>
</div>   

</body>
</html>