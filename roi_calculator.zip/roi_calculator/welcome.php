<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Profile</title>

	<!--===CSS files ===-->
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
	<link rel="stylesheet" href="css/font-awesome.min.css" />
	<link rel="stylesheet" href="css/linea-icon.css" />
	<link rel="stylesheet" href="css/fancy-buttons.css" />
    <link rel="stylesheet" href="style.css" />
    
    <!--===Javascript files ===-->
    <script src="custom.js" type="text/javascript"></script>
	<script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/angular.min.js" type="text/javascript"></script>
</head>

<body>
<?php 
if(isset($_POST['previous2'])){ 
	$_SESSION['total_icall_pro'] =  $_SESSION['total_icall']; 
}

$total_pbx = 0;
$three_years = 36;
$four_years = 48;
$five_years = 60;
$six_years = 72;
if(isset($_POST['contract'])){
	$contract_status = $_POST['contract'];
	if($contract_status == 'yr3'){
		$total_icall =  $_SESSION['total_icall'] * $three_years;
		
	}else if($contract_status == 'yr4'){
		$total_icall =  $_SESSION['total_icall'] * $four_years;
		
	}else if($contract_status == 'yr5'){
		$total_icall =  $_SESSION['total_icall'] * $five_years;
		
	}else if($contract_status == 'yr6'){
		$total_icall =  $_SESSION['total_icall'] * $six_years;
		
	}else{
		$total_icall = $_SESSION['total_icall'];
		
	}
	$_SESSION['new_total_icall'] = $total_icall;

							

}

if(isset($_POST['bus_profile'])){
	if($_SESSION['total_icall'] == NULL){
		$_SESSION['total_icall_pro'] = 0;
	}else{
		$_SESSION['total_icall_pro'] =  $_SESSION['total_icall'];
	}
		
}

if(isset($_POST['continue'])){
	if(!isset($_SESSION['total_icall'])){
		$_SESSION['total_icall_pro'] = 0;
	}else{
		$_SESSION['total_icall_pro'] =  $_SESSION['total_icall'];
	}
		
}

?>

<div class="row">
	<div id="main_container" class="col-md-12 box">
		<div id="calc_content" style="display:block">
                <div class="col-md-8 content">
                    <table>
                    <form method="post">
                    <button class="menu col-md-4" formaction="welcome.php" name="bus_profile"><div style="float:left;"><h1>1</h1></div><div><br />Current Business Profile</div></button>
                    <button class="menu col-md-4" disabled="disabled" name="usage_fees"><div style="float:left;"><h1>2</h1></div><div><br />Your Usage Fee</div></button>
                    <button class="menu col-md-4" disabled="disabled" name="your_system"><div style="float:left;"><h1>3</h1></div><div><br />Your System</div></button>				
                    </form>
                    </table>
                    <!-- For Profile -->
                    <div id="calc_body">
                        <form  id="profile" name="profile" method="post">
                            <table style="display:inline-block">
                                <tr>
                                    <th style="text-align:left">How many locations</th>
                                    <td><input type="number" name="location" required="required" value="<?php if(isset($_POST['previous2']) || isset($_POST['contract']) || isset($_POST['bus_profile']) || isset($_POST['continue'])){ 
									if(!isset($_SESSION['location_no'])){
										echo '';
									}else{
										echo $_SESSION['location_no']; 
									}}?>"/></td>
                                </tr>
                                <tr>
                                    <th style="text-align:left">How many total employees</th>
                                    <td><input type="number" name="employee" required="required"  value="<?php if(isset($_POST['previous2']) || isset($_POST['contract']) || isset($_POST['bus_profile']) || isset($_POST['continue'])){ 
									if(!isset($_SESSION['employee_no'])){
										echo '';
									}else{
										echo $_SESSION['employee_no']; 
									}}?>" /></td>
                                </tr>
                                 <tr>
                                    <th style="text-align:left">How many employees work from home</th>
                                    <td><input type="number" name="home_employee" required="required" value="<?php if(isset($_POST['previous2']) || isset($_POST['contract']) || isset($_POST['bus_profile']) || isset($_POST['continue'])){ 
									if(!isset($_SESSION['home_worker_no'])){
										echo '';
									}else{
										echo $_SESSION['home_worker_no']; 
									}}?>" /></td>
                                </tr>
                                
                            </table>
                            <div> 	
                                <input type="submit" name="next1" value="Next" formaction="usage.php"  style="margin-top:20px; margin-left: 20px; float:right" />
                            	<input type="submit" name="previous1" value="Previous" formaction="index.php" style="margin-top:20px; float:right"/>
                            	
                            </div>
                            
                        </form>   
                        
                                            
                    </div>     
                </div>
                <div class="col-md-4 content">
                    <table>
                        <tr>
                            <h2>Phone Savings</h2>
                        </tr>
                        <tr>
                            <th></th>
                            <th>RingCentral Office</th>
                            <th>On-Premise PBX</th>
                        
                        </tr>
                        <tr>
                            <th>Total Monthly Cost</th>
                            <td>$<?php 
									if(isset($_POST['previous2'])){ 
										echo $_SESSION['total_icall_pro'];
									}else if(isset($_POST['contract'])){
										echo $_SESSION['new_total_icall'];
									}else if(isset($_POST['continue'])){
										echo $_SESSION['total_icall_pro'];
									}else if(isset($_POST['bus_profile'])){
										echo $_SESSION['total_icall_pro'];;
									}else{
										echo 0;
									}

							  ?></td>
                            <td>$<?php 
									if(isset($_POST['previous2'])){
										echo 0;
									}else if(isset($_POST['contract'])){
										echo 0;
									}else if(isset($_POST['continue'])){
										echo 0;
									}else{
										echo 0;
									}
							
							
							?></td>
                        </tr>
                        <tr>
                            <th>Your 2-Years Savings</th>
                            <td>$0 Save 0%</td>
                            
                        </tr>
                    
                    </table>
                    <tr style="margin-top:200px">
                    	<form method="post" action="" onchange='this.submit()'>
                        <td><input type="radio" name="contract" value="non" <?php if(!isset($_POST['contract']) || (isset($_POST['contract']) && $_POST['contract'] == 'non' )){ echo'checked = "checked"' ; }?>/>  Monthly, no contract </td><br/>
                        <td><input type="radio" name="contract" value="yr3"  <?php if(isset($_POST['contract']) && $_POST['contract'] == 'yr3'){ echo'checked = "checked"' ; }?>/>  Monthly, 3 year contract</td><br/>
                        <td><input type="radio" name="contract" value="yr4" <?php if(isset($_POST['contract']) && $_POST['contract'] == 'yr4'){ echo'checked = "checked"' ; }?>/>  Monthly, 4 year contract</td><br/>
                        <td><input type="radio" name="contract" value="yr5" <?php if(isset($_POST['contract']) && $_POST['contract'] == 'yr5'){ echo'checked = "checked"' ; }?>/>  Monthly, 5 year contract</td><br/>
                        <td><input type="radio" name="contract" value="yr6" <?php if(isset($_POST['contract']) && $_POST['contract'] == 'yr6'){ echo'checked = "checked"' ; }?>/>  Monthly, 6 year contract</td><br/>
                        <noscript><input type="submit" name="next4" value="check" style="margin-top:20px; margin-left: 20px; float:right" /></noscript>
                     </form>
                     </tr>
                     
                    
				
                </div>
		</div>
	</div>
</div>


</body>
</html>

 