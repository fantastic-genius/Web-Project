<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html lang="en-US">
<head>
	
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>ROI Calculator</title>

	<!--===CSS files ===-->
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
	<link rel="stylesheet" href="css/font-awesome.min.css" />
	<link rel="stylesheet" href="css/linea-icon.css" />
	<link rel="stylesheet" href="css/fancy-buttons.css" />
    <link rel="stylesheet" href="style.css" />
    
    <!--===Javascript files ===-->
    <script src="custom.js" type="text/javascript"></script>
    <script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/angular.min.js" type="text/javascript"></script>
</head>

<body>
<div class="row">
	<div id="main_container" class="col-md-12 box">
            <div id="welcome_content" style="display:block">
                <h1>Welcome</h1>
                <h3>In just a few quick steps, see how much RingCentral can save
                your business compared to the cost of an on-premise PBX.</h3>
                <h5>Fill in the form that follows using your business phone bill</h5>
                <h2>Let’s Get Started</h2>
                <h4>How did you purchase your phone system?</h4> 
                 <div>
                 <form method="post">
                 <tr>
                 	<select id="option_select_id" class="option_select"  style="width:200px; height:30px; font-size:14px; font-family:Tahoma, Geneva, sans-serif; color:#F00; background:#09F">
                    	
                        <option value="" hidden="true">Please Select</option>
                        <option id="buy" value="buy">Buy</option>
                        <option id="lease" value="lease">Lease</option>
                        
                        
                    </select>
                    </tr>
                    <tr>
 
                		<button name="continue" value="continue" formaction="welcome.php" style="margin-top:20px">Continue</button>
                 
                 </tr>
               </form>
               
                                      
            </div> 			
         </div>
    </div>
</div>






</body>
</html>