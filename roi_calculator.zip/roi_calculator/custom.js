// JavaScript Document

//Select Drop Down
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}




<!-- Two layers showing one at a time with button click -->
function setVisibility(id1,id2) {
if(document.getElementById('continue').value=='continue'){
//document.getElementById('bt1').value = 'Show Box 4';
document.getElementById(id1).style.display = 'inline';
document.getElementById(id2).style.display = 'none';
}
}








$(document).ready(function(){

      $("input[type=submit]").attr("disabled", "disabled");
      $('input, textarea').change(function(){
            var validate;

	    var telecom = $('#telecom').val();
	    var maintenance = $('#maintenance').val();
	    var addition = $('#addition').val();
		var lease_cost = $('#lease_cost').val()
		var staffing = $('#staffing').val();;
		
	    if ( telecom == '' && maintenance == '' && addition == ''  && lease_cost == ''  && staffing == '') {
                  validate = false;
            } 

            else if (  telecom != '' && maintenance != '' && addition != ''  && lease_cost != ''  && staffing != '' ) {   
                  validate = true;
	     }

            if(validate == true) { 
				$("input[type=submit]").removeAttr("disabled");
	      }
      });
 
     $('input:first').trigger('change');
});