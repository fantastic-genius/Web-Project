// JavaScript Document

// Copy 1 carosel JS
$('.carousel').carousel();


//bootstrap
$('.carousel').carousel({

    interval: 1000 //changes the speed

});