<!-- This sercices Continue Reading File -->


<!-- ERP Modal Start--> 
<div class="modal fade" id="erp_rd" role="dialog">
   <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close cus_close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Enterprise Resource Planning (ERP)</h4>
        </div>
        <div class="modal-body">
          <p>
          	Odoo (formerly known as OpenERP) is a suite of open-source enterprise management applications. Odoo is the fastest
            evolving business software in the world, which has a complete suite of business applications covering all business
            needs, from Website/E-commerce down to manufacturing, inventory and accounting, all seamlessly integrated
          </p>
          <p>
            We provide all kinds of Odoo related services starting from functional consultancy, implementation, support,
            maintenance, customization and development of new business modules. We also undertake Odoo Technical Training as
            well as Odoo Functional Training. We have an expert team with more than 8 years of experience in Odoo(since it was
            Tiny ERP). Our Odoo team is accompanied by a dedicated network/system admin team who manages the Odoo servers of our
            customers hosted remotely.
          </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default btn-danger" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
</div>
<!-- ERP Modal End-->

<!-- Beacon SMS Modal Start-->
<div class="modal fade" id="beacon_rd" role="dialog">
   <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Beacon School Management System</h4>
        </div>
        <div class="modal-body">
          <p>
          	Are you thinking of automating your school activities to reduce stress? We got the right solution for you, Beacon
            School Management System software. Beacon SMS is a school management system that is designed to register, record,
            maintain, track and search for students, teachers, parents and school information and activities 
          </p>
          <p>
          	Beacon has different modules which include:
          </p>
          
          <ul>
          	<li>- Student Module</li>
            <li>- Teachers Module</li>
            <li>- Parent Module</li>
          </ul>
          <p>
          	Beacon benefits include:
          </p>
          <ul>
          	<li>Upload of students' results, assignments, etc by teachers from their respective offices without stress.</li>
            <li>Marking of attendance by teachers using mobile phones</li>
            <li>Teachers can add, edit, and view their lesson notes. A beautiful platform for documentation. Yes, even without
            internet connection (if the offline version is installed in your school).</li>
            <li>Students can view report cards, attend to assignments and view shared files.</li>
            <li>Parents are not excluded. Let them login and view their children performances, track payments, and send messages
            to teachers/school from the comfort of their rooms.</li>
            <li>All these can be assessed on both computer and mobile phones</li>
          </ul>
          
           <p>
          	The available packages include:
          </p>
          <ul>
          	<li>- Basic: For schools with less than 200 students</li>
            <li>- Premium: For schools with students ranging from 200 to 1000</li>
            <li>- Platinum: For schools with students above 1000</li>
          </ul>
          
          <h3>
          	Pricing
          </h3>
          <p>
          	Pricing is on termly basis per student
          </p>
          <ul>
          	<li>- Basic: Eight hundred naira per student</li>
            <li>- Premium: Four hundred naira per student</li>
            <li>- Platinum: Three hundred and Fifty naira per student</li>
          </ul>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
</div>
<!-- Beacon SMS Modal End-->

<!-- Website Development Start--> 
<div class="modal fade" id="web_rd" role="dialog">
   <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close cus_close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Website Development and Maintenance</h4>
        </div>
        <div class="modal-body">
          <p>
          	Our company, BigFixtech’s dedicated web development team provides total and cost-effective web solutions to its
            valuable customers. We've the proven experience and proficiency in designing website that accomplish something by
            bringing in enquiries, which generate sales and are an asset to your business.
          </p>
          <p>
            Our services includes
          </p>
          <ul>
          	<li>Website design & Development</li>
            <li>Website Redesign</li>
            <li>Website Maintanace</li>
            <li>Web application development</li>
            <li>Content Management Systems</li>
            <li>E-commerce solutions</li>
          </ul>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default btn-danger" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
</div>
<!-- Website development Modal End-->
  
<!-- Enterprise Service Start -->
<div class="modal fade" id="ent_service_rd" role="dialog">
   <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Enterprise Services</h4>
        </div>
        <div class="modal-body">
          <p>
          	BigFix Technologies provides Server and Storage services to minimize your IT complexities, hence improving the performance and
            optimizing the Total Cost of your Ownership and Management, therefore increasing your revenue. BigFix Technologies
            intends to provide performance based system’s utilization and system’s management for your Server environment. 
          </p>
          <p>
          	Our server and storage services include:
          </p>
            
          <ul>
          	<li>Server implementationt</li>
            <li>System integration and Virtualization services</li>
            <li>Data center consolidation</li>
            <li>Storage implementation</li>
            <li>Storage consolidation</li>
            <li>Storage management</li>
            <li>Storage virtualization</li>
            <li>Data protection</li>
          </ul>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
</div>
<!-- Enterprise Service End -->

<!-- CCTV Installation Modal Start-->
<div class="modal fade" id="cctv_rd" role="dialog">
   <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">CCTV installation</h4>
        </div>
        <div class="modal-body">
          <p>
          	BigFix offer CCTV installation and maintenance service. Depending on your requirements, our team of experts can
            advise you the best way to protect and monitor you, your home or business we can create a truly bespoke service to
            fit your budget and space. Every installation is carried out by one of our specialist engineers so you can be
            assured everything will be completed to the highest standard. 
          </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
</div>
<!-- Fire Alarm Soltion Modal End-->


<!-- Biometric Modal Start-->
<div class="modal fade" id="bio_rd" role="dialog">
   <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Biometric Solutions</h4>
        </div>
        <div class="modal-body">
          <p>
          	BigFix's Biometrics Division delivers biometrics systems, consulting and training.
			BigFixs’ biometrics services include the delivery of the following for government and private sector customers: 
          </p>
            
          <ul>
          	<li>Enrollment and Identification Systems using Biometric Data</li>
            <li>Entry Point Access Control using Biometric Data</li>
            <li>Identification Card Systems containing Biometric Data</li>
            <li>Integrated Biometrics Systems, Networks, Databases and Infrastructure</li>
            <li>Biometrics Training – Technical, System and Operational Components</li>
            <li>Biometrics Data Capture and Recognition including</li>
            <li>Fingerprint and handprint </li>
            <li>Facial Scan and Retina Scan </li>
            <li>Voice Print</li>
            <li>DNA</li>
          </ul>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
</div>
<!-- Biometric Modal End-->


<!-- Fire Alarm Solution Modal Start-->
<div class="modal fade" id="fire_rd" role="dialog">
   <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Fire Alarm Solutions</h4>
        </div>
        <div class="modal-body">
          <p>
          	Detecting a fire and intrusion early can mean the difference between losing everything and keeping loss and damage
          	to a minimum. Fire alarm systems are expected to help protect people, property, and assets. BigFix helps in the
          	Installation, testing and maintenance of Fire Alarm systems, Smoke Detector and Burglar Alarm systems within
            companies and houeseholds facilities. We also carry support service to our clients.
          </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
</div>
<!-- Fire Alarm Soltion Modal End-->