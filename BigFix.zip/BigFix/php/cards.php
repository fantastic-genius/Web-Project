<!-- This is the card denoting clients file  -->

<!--Features container Starts -->
						<ul id="card-ul" class="features-hold baraja-container">
						
							<!-- Single Feature Starts -->
							<li class="single-feature" title="mtn">
								<img src="images/clients/mtn.png" alt="" class="feature-image card_image" /><!-- Feature Icon -->
								<h4 class="feature-title color-scheme">MTN</h4>
								<!--p class="feature-text">
									Curabitur posuere feugiat ipsum, sed elementum tortor maximus ut.
								</p-->
								
									<a href="#" class="fancy-button button-line btn-col small vertical">
										Details
										<span class="icon">
											<i class="fa fa-leaf"></i>
										</span>
									</a>
								
							</li>
							<!-- Single Feature Ends -->
							
							<!-- Single Feature Starts -->
							<li class="single-feature" title="tsc">
								<img src="images/clients/tsc.png" alt="" class="feature-image card_image" /><!-- Feature Icon -->
								<h4 class="feature-title color-scheme">The Source Computers</h4>
								<!--p class="feature-text">
									Curabitur posuere feugiat ipsum, sed elementum tortor maximus ut
								</p-->
								<a href="#" class="fancy-button button-line btn-col small zoom">
									Details
									<span class="icon">
										<i class="fa fa-leaf"></i>
									</span>
								</a>
							</li>
							<!-- Single Feature Ends -->
							
							<!-- Single Feature Starts -->
							<li class="single-feature" title="hajj_mabrur">
								<img src="images/clients/hajj-mabrur.jpg" alt="" class="feature-image card_image" /><!-- Feature Icon -->
								<h4 class="feature-title color-scheme">Hajj Mabrur Ventures Limited</h4>
								<!--p class="feature-text">
									Curabitur posuere feugiat ipsum, sed elementum tortor maximus ut
								</p-->
								<a href="#" class="fancy-button button-line btn-col small zoom">
									Details
									<span class="icon">
										<i class="fa fa-leaf"></i>
									</span>
								</a>
							</li>
							<!-- Single Feature Ends -->
							
							<!-- Single Feature Starts -->
							<li class="single-feature" title="sungas">
								<img src="images/clients/sungas.png" alt="" class="feature-image card_image" /><!-- Feature Icon -->
								<h4 class="feature-title color-scheme">Sungas</h4>
								<!--p class="feature-text">
									Curabitur posuere feugiat ipsum, sed elementum tortor maximus ut
								</p-->
								<a href="#" class="fancy-button button-line btn-col small zoom">
									Details
									<span class="icon">
										<i class="fa fa-leaf"></i>
									</span>
								</a>
							</li>
							<!-- Single Feature Ends -->
							
							<!-- Single Feature Starts -->
							<li class="single-feature" title="huawei">
								<img src="images/clients/jnci.png" alt="" class="feature-image card_image" /><!-- Feature Icon -->
								<h4 class="feature-title color-scheme">JNCI</h4>
								<!--p class="feature-text">
									Curabitur posuere feugiat ipsum, sed elementum tortor maximus ut
								</p-->
								<a href="#" class="fancy-button button-line btn-col small zoom">
									Details
									<span class="icon">
										<i class="fa fa-leaf"></i>
									</span>
								</a>
							</li>
							<!-- Single Feature Ends -->
							
							<!-- Single Feature Starts -->
							<li class="single-feature" title="Visafone">
								<img src="images/clients/cyberspace.png" alt="" class="feature-image card_image" /><!-- Feature Icon -->
								<h4 class="feature-title color-scheme">Cyberspace</h4>
								<!--p class="feature-text">
									Curabitur posuere feugiat ipsum, sed elementum tortor maximus ut
								</p-->
								<a href="#" class="fancy-button button-line btn-col small zoom">
									Details
									<span class="icon">
										<i class="fa fa-leaf"></i>
									</span>
								</a>
							</li>
							<!-- Single Feature Ends -->
							
							<!-- Single Feature Starts -->
							<li class="single-feature" title="unlimited Google fonts">
								<img src="images/clients/prorad.png" alt="" class="feature-image card_image" /><!-- Feature Icon -->
								<h4 class="feature-title color-scheme">ProRad Health Centers</h4>
								<!--p class="feature-text">
									Curabitur posuere feugiat ipsum, sed elementum tortor maximus ut
								</p-->
								<a href="#" class="fancy-button button-line btn-col small zoom">
									Details
									<span class="icon">
										<i class="fa fa-leaf"></i>
									</span>
								</a>
							</li>
							<!-- Single Feature Ends -->
							
							<!-- Single Feature Starts -->
							<li class="single-feature" title="Feature heading">
								<img src="images/clients/waec.png" alt="" class="feature-image card_image" /><!-- Feature Icon -->
								<h4 class="feature-title color-scheme">WAEC</h4>
								<!--p class="feature-text">
									Curabitur posuere feugiat ipsum, sed elementum tortor maximus ut
								</p-->
								<a href="#" class="fancy-button button-line btn-col small zoom">
									Details
									<span class="icon">
										<i class="fa fa-leaf"></i>
									</span>
								</a>
							</li>
							<!-- Single Feature Ends -->
                            
                            <!-- Single Feature Starts -->
							<li class="single-feature" title="Feature heading">
								<img src="images/clients/laplace.png" alt="" class="feature-image card_image" /><!-- Feature Icon -->
								<h4 class="feature-title color-scheme">LAPLACE Technologies</h4>
								<!--p class="feature-text">
									Curabitur posuere feugiat ipsum, sed elementum tortor maximus ut
								</p-->
								<a href="#" class="fancy-button button-line btn-col small zoom">
									Details
									<span class="icon">
										<i class="fa fa-leaf"></i>
									</span>
								</a>
							</li>
							<!-- Single Feature Ends -->
                            
                            <!-- Single Feature Starts -->
							<li class="single-feature" title="Feature heading">
								<img src="images/clients/dreampark.png" alt="" class="feature-image card_image" /><!-- Feature Icon -->
								<h4 class="feature-title color-scheme">Dream Park Montessori School</h4>
								<!--p class="feature-text">
									Curabitur posuere feugiat ipsum, sed elementum tortor maximus ut
								</p-->
								<a href="#" class="fancy-button button-line btn-col small zoom">
									Details
									<span class="icon">
										<i class="fa fa-leaf"></i>
									</span>
								</a>
							</li>
							<!-- Single Feature Ends -->
                            
                            <!-- Single Feature Starts -->
							<li class="single-feature" title="Feature heading">
								<img src="images/clients/bodej.png" alt="" class="feature-image card_image" /><!-- Feature Icon -->
								<h4 class="feature-title color-scheme">Bodej Investment Limited</h4>
								<!--p class="feature-text">
									Curabitur posuere feugiat ipsum, sed elementum tortor maximus ut
								</p-->
								<a href="#" class="fancy-button button-line btn-col small zoom">
									Details
									<span class="icon">
										<i class="fa fa-leaf"></i>
									</span>
								</a>
							</li>
							<!-- Single Feature Ends -->
						</ul>
						<!--Features container Ends -->