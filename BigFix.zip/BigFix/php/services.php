<!-- This is services page file -->

<!--=== Services section Starts ===-->
<section id="section-services" class="services-wrap">
		<div class="container services">
			<div class="row">
			
				<div class="col-md-10 col-md-offset-1 center section-title">
					<h3>What we do best</h3>
				</div>
                
                <!-- Column for Software services Starts--> 
				<div class="col-md-6 col-sm-6">
                	<!-- Single Service Starts -->
                    <div class="col-md-12 col-sm-12 service animated" data-animation="fadeInLeft" data-animation-delay="700">
                        <span class="service-icon center"><i class="icon icon-basic-book-pencil fa-3x"></i></span>
                        <div class="service-desc">
                            <h4 class="service-title color-scheme">Enterprise Resource Planning (ERP)</h4>
                            <p class="service-description justify">
                                Odoo (formerly known as OpenERP) is a suite of open-source enterprise management applications.
                                Odoo is the fastest evolving business software in the world, which has a complete suite of ...
                            </p>
                            <button type="button" class="btn btn-info btn-group-lg con_read" data-toggle="modal" data-target="#erp_rd">Continue Reading</button>
                        </div>
                    </div>
                    <!-- Single Service Ends -->
                    
                    <!-- Single Service Starts -->
                    <div class="col-md-12 col-sm-12 service animated" data-animation="fadeInRight" data-animation-delay="700">
                        <span class="service-icon center"><i class="icon icon-basic-accelerator fa-3x"></i></span>
                        <div class="service-desc">
                            <h4 class="service-title color-scheme">Beacon School Management System</h4>
                            <p class="service-description justify">
                               Are you thinking of automating your school activities to reduce stress? We got the right
                               solution for you, Beacon School Management System software. Beacon SMS is a school management
                               system that
                               ...
                            </p>
                            <button type="button" class="btn btn-info btn-group-lg con_read" data-toggle="modal" data-target="#beacon_rd">Continue Reading</button>
                        </div>
                    </div>
                    <!-- Single Service Ends -->
                    
                    <!-- Single Service Starts -->
                    <div class="col-md-12 col-sm-12 service animated" data-animation="fadeInUp" data-animation-delay="700">
                        <span class="service-icon center"><i class="icon icon-basic-globe fa-3x"></i></span>
                        <div class="service-desc">
                            <h4 class="service-title color-scheme">Websites Development and Maintenance</h4>
                            <p class="service-description justify">
                                Our company, BigFixtech’s dedicated web development team provides total and cost-effective web
                                solutions to its valuable customers. We've the proven experience and proficiency in designing
                                ...
                            </p>
                            <button type="button" class="btn btn-info btn-group-lg con_read" data-toggle="modal" data-target="#web_rd">Continue Reading</button>
                                
                        </div>
                    </div>
                    <!-- Single Service Ends -->
                      
                </div>
                <!-- Column for Software services Starts--> 
                
                <!-- Column for IT infrastructure services Starts-->
                <div class="col-md-6 col-sm-6">
                    <!-- Single Service Starts -->
                    <div class="col-md-12 col-sm-12 service animated" data-animation="fadeInUp" data-animation-delay="700">
                        <span class="service-icon center"><i class="icon icon-basic-paperplane fa-3x"></i></span>
                        <div class="service-desc">
                            <h4 class="service-title color-scheme">Enterprise Services</h4>
                            <p class="service-description justify">
                                BigFix Technologies helps you build and manage a dynamic & optimized infrastructure that
                                supports your business operations using quality OEM server and storage.
                            </p>
                            <button type="button" class="btn btn-info btn-group-lg con_read" data-toggle="modal" data-target="#ent_service_rd">Continue Reading</button>
                        </div>
                    </div>
                    <!-- Single Service Ends -->
                    
                    <!-- Single Service Starts -->
                    <div class="col-md-12 col-sm-12 service animated" data-animation="fadeInUp" data-animation-delay="700">
                        <span class="service-icon center"><i class="fa fa-camera fa-3x"></i></span>
                        <div class="service-desc">
                            <h4 class="service-title color-scheme">CCTV Installation</h4>
                            <p class="service-description justify">
                               BigFix offer CCTV installation and maintenance service. Depending on your requirements, our team
                               of experts can advise you the best way to protect and monitor you, your home or business we can
                               ...
                            </p>
                            <button type="button" class="btn btn-info btn-group-lg con_read" data-toggle="modal" data-target="#cctv_rd">Continue Reading</button>
                        </div>
                    </div>
                    <!-- Single Service Ends -->
                    
                    <!-- Single Service Starts -->
                    <div class="col-md-12 col-sm-12 service animated" data-animation="fadeInUp" data-animation-delay="700">
                        <span class="service-icon center"><i class="material-icons md-60">fingerprint</i></span>
                        <div class="service-desc">
                            <h4 class="service-title color-scheme">Biometrics Solutions</h4>
                            <p class="service-description justify">
                              	BigFix's Biometrics Division delivers biometrics systems, consulting and training.
								BigFixs’ biometrics services include the delivery of the following for government and private		 								sector customers:
                            </p>
                            <button type="button" class="btn btn-info btn-group-lg con_read" data-toggle="modal" data-target="#bio_rd">Continue Reading</button>
                        </div>
                    </div>
                    <!-- Single Service Ends -->
                    
                    <!-- Single Service Starts -->
                    <div class="col-md-12 col-sm-12 service animated" data-animation="fadeInUp" data-animation-delay="700">
                        <span class="service-icon center"><i class="material-icons md-60">access_alarm</i></span>
                        <div class="service-desc">
                            <h4 class="service-title color-scheme">Fire Alarm Solutions</h4>
                            <p class="service-description justify">
                               Detecting a fire and intrusion early can mean the difference between losing everything and
                               keeping loss and damage to a minimum. Fire alarm systems are expected to help protect people ...
                            </p>
                            <button type="button" class="btn btn-info btn-group-lg con_read" data-toggle="modal" data-target="#fire_rd">Continue Reading</button>
                        </div>
                    </div>
                    <!-- Single Service Ends -->
                
                
                </div>
                <!-- Column for IT infrastructure services Ends-->     
                
			</div>
		</div>
	</section>
	<!--=== Services section Ends ===-->