<!-- Single screenshot starts -->
				<div class="col-md-4 col-sm-4 col-xs-6">
					<div class="screenshot">
						<div class="photo-box">
							<img src="images/project/hajjmabrur_proj.png" alt="" class="cus_screenshots" />
							<div class="photo-overlay">
								<h4>Hajj Mabrur Website Development</h4>
							</div>
							<span class="photo-zoom">
								<a href="#" class="view-project"><i class="fa fa-search-plus fa-2x"></i></a>
							</span>
						</div>
					</div>
				</div>
				<!-- Single screenshot ends -->
				
				<!-- Single screenshot starts -->
				<div class="col-md-4 col-sm-4 col-xs-6">
					<div class="screenshot">
						<div class="photo-box">
							<img src="images/project/tsc_proj.png" alt="" class="cus_screenshots" />
							<div class="photo-overlay">
								<h4>Odoo ERP implementation for TSC</h4>
							</div>
							<span class="photo-zoom">
								<a href="#" class="view-project"><i class="fa fa-search-plus fa-2x"></i></a>
							</span>
						</div>
						
					</div>
				</div>
				<!-- Single screenshot ends -->
				
				<!-- Single screenshot starts -->
				<div class="col-md-4 col-sm-4 col-xs-6">
					<div class="screenshot">
						<div class="photo-box">
							<img src="images/project/jnci_proj.png" alt="" class="cus_screenshots" />
							<div class="photo-overlay">
								<h4>CCTV installation for JNCI</h4>
							</div>
							<span class="photo-zoom">
								<a href="#" class="view-project"><i class="fa fa-search-plus fa-2x"></i></a>
							</span>
						</div>
						
					</div>
				</div>
				<!-- Single screenshot ends -->
				
				<!-- Single screenshot starts -->
				<div class="col-md-4 col-sm-4 col-xs-6">
					<div class="screenshot">
						<div class="photo-box">
							<img src="images/project/cyberspace_proj.png" alt="" class="cus_screenshots" />
							<div class="photo-overlay">
								<h4>Infrastructural Service for Cyberspace</h4>
							</div>
							<span class="photo-zoom">
								<a href="#" class="view-project"><i class="fa fa-search-plus fa-2x"></i></a>
							</span>
						</div>
						
					</div>
				</div>
				<!-- Single screenshot ends -->
				
				<!-- Single screenshot starts -->
				<div class="col-md-4 col-sm-4 col-xs-6">
					<div class="screenshot">
						<div class="photo-box">
							<img src="images/project/prorad_proj.png" alt="" class="cus_screenshots" />
							<div class="photo-overlay">
								<h4>CCTV, Fire Alarm and Acess control for ProRad Health Centers</h4>
							</div>
							<span class="photo-zoom">
								<a href="#" class="view-project"><i class="fa fa-search-plus fa-2x"></i></a>
							</span>
						</div>
						
					</div>
				</div>
				<!-- Single screenshot ends -->
				
				<!-- Single screenshot starts -->
				<div class="col-md-4 col-sm-4 col-xs-6">
					<div class="screenshot">
						<div class="photo-box">
							<img src="images/project/waec_proj.png" alt="" class="cus_screenshots" />
							<div class="photo-overlay">
								<h4>Organize training on Cisco cybersecurity for WAEC</h4>
							</div>
							<span class="photo-zoom">
								<a href="#" class="view-project"><i class="fa fa-search-plus fa-2x"></i></a>
							</span>
						</div>
						
					</div>
				</div>
				<!-- Single screenshot ends -->
                
                <!-- Single screenshot starts -->
				<div class="col-md-4 col-sm-4 col-xs-6">
					<div class="screenshot">
						<div class="photo-box">
							<img src="images/project/sungas_proj.jpg" alt="" class="cus_screenshots" />
							<div class="photo-overlay">
								<h4>Odoo ERP implementation for Sungas</h4>
							</div>
							<span class="photo-zoom">
								<a href="#" class="view-project"><i class="fa fa-search-plus fa-2x"></i></a>
							</span>
						</div>
						
					</div>
				</div>
				<!-- Single screenshot ends -->
                
                <!-- Single screenshot starts -->
				<div class="col-md-4 col-sm-4 col-xs-6">
					<div class="screenshot">
						<div class="photo-box">
							<img src="images/project/laplace_proj.png" alt="" class="cus_screenshots" />
							<div class="photo-overlay">
								<h4>Infrastructural Service for LAPLACE</h4>
							</div>
							<span class="photo-zoom">
								<a href="#" class="view-project"><i class="fa fa-search-plus fa-2x"></i></a>
							</span>
						</div>
						
					</div>
				</div>
				<!-- Single screenshot ends -->
                
                <!-- Single screenshot starts -->
				<div class="col-md-4 col-sm-4 col-xs-6">
					<div class="screenshot">
						<div class="photo-box">
							<img src="images/project/dreampark_proj.png" alt="" class="cus_screenshots" />
							<div class="photo-overlay">
								<h4>Beacon SMS for Dream Park montessori school</h4>
							</div>
							<span class="photo-zoom">
								<a href="#" class="view-project"><i class="fa fa-search-plus fa-2x"></i></a>
							</span>
						</div>
						
					</div>
				</div>
				<!-- Single screenshot ends -->
                
                <!-- Single screenshot starts -->
				<div class="col-md-4 col-sm-4 col-xs-6">
					<div class="screenshot">
						<div class="photo-box">
							<img src="images/project/bodej_proj.PNG" alt="" class="cus_screenshots" />
							<div class="photo-overlay">
								<h4>Website Design for Bodej Investment ltd</h4>
							</div>
							<span class="photo-zoom">
								<a href="#" class="view-project"><i class="fa fa-search-plus fa-2x"></i></a>
							</span>
						</div>
						
					</div>
				</div>
				<!-- Single screenshot ends -->
                
                <!-- Single screenshot starts -->
				<div class="col-md-4 col-sm-4 col-xs-6">
					<div class="screenshot">
						<div class="photo-box">
							<img src="images/project/mtn_proj.png" alt="" class="cus_screenshots" />
							<div class="photo-overlay">
								<h4>Infrastructural Service for MTN</h4>
							</div>
							<span class="photo-zoom">
								<a href="#" class="view-project"><i class="fa fa-search-plus fa-2x"></i></a>
							</span>
						</div>
						
					</div>
				</div>
				<!-- Single screenshot ends -->
                
                <!-- Single screenshot starts -->
				<div class="col-md-4 col-sm-4 col-xs-6">
					<div class="screenshot">
						<div class="photo-box">
							<img src="images/project/justhalal_proj.png" alt="" class="cus_screenshots" />
							<div class="photo-overlay">
								<h4>Just Halal Website Development</h4>
							</div>
							<span class="photo-zoom">
								<a href="#" class="view-project"><i class="fa fa-search-plus fa-2x"></i></a>
							</span>
						</div>
						
					</div>
				</div>
				<!-- Single screenshot ends -->
                
                
                
                