<?php
	$DB_HOST = 'localhost';
	$DB_USERNAME = 'root';
	$DB_PASSWORD = '';
	$DB_NAME = 'dreampark';
	
?>