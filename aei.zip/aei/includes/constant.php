<?php
	$DB_HOST = "localhost";
	$DB_USERNAME = "root";
	$DB_PASWWORD = "";
	$DB_NAME = "wordpress";

?>