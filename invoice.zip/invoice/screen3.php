<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Screen 3</title>

<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" />
<link rel="stylesheet" href="css/animate.css" type="text/css" />
<link href='https://fonts.googleapis.com/css?family=Concert One' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Arima Madurai' rel='stylesheet'>
<link rel="stylesheet" href="style.css" type="text/css" />



<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/popper.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="custom.js" type="text/javascript"></script>
</head>

<body>
<section>
	<div id="screen3-container" class="row">
        <div class="col-md-10 col-sm-12 con-border">
        	<h2>SUCCESS!</h2><br /><br />
            <h5>Your Invoice is getting ready to be printed and mailed to your client</h5><br /><br />
            <h5>You can track the status here: ___________</h5><br /><br />
            <h5>We have also sent the link to your e-mail</h5><br />
        </div>
    </div>
</section>
</body>
</html>